﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBook
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstBooks = New System.Windows.Forms.ListBox()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblSubject = New System.Windows.Forms.Label()
        Me.lblSeller = New System.Windows.Forms.Label()
        Me.lblPurchase = New System.Windows.Forms.Label()
        Me.lblPurchaser = New System.Windows.Forms.Label()
        Me.lblSale = New System.Windows.Forms.Label()
        Me.lblRating = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtRating = New System.Windows.Forms.TextBox()
        Me.txtSale = New System.Windows.Forms.TextBox()
        Me.txtPurchaser = New System.Windows.Forms.TextBox()
        Me.txtPurchase = New System.Windows.Forms.TextBox()
        Me.txtSeller = New System.Windows.Forms.TextBox()
        Me.txtSubject = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnSort = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstBooks
        '
        Me.lstBooks.FormattingEnabled = True
        Me.lstBooks.ItemHeight = 20
        Me.lstBooks.Location = New System.Drawing.Point(42, 109)
        Me.lstBooks.Name = "lstBooks"
        Me.lstBooks.Size = New System.Drawing.Size(729, 324)
        Me.lstBooks.TabIndex = 0
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(103, 439)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(167, 58)
        Me.btnHome.TabIndex = 1
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(325, 439)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(167, 58)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblHeading.Location = New System.Drawing.Point(290, 71)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(246, 24)
        Me.lblHeading.TabIndex = 4
        Me.lblHeading.Text = "Secondhand book sales"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblTitle.Location = New System.Drawing.Point(218, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(399, 28)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = "Galactic Senior Secondary School"
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(553, 439)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(167, 58)
        Me.btnEdit.TabIndex = 5
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(835, 63)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(117, 20)
        Me.lblName.TabIndex = 6
        Me.lblName.Text = "Textbook Name:"
        '
        'lblSubject
        '
        Me.lblSubject.AutoSize = True
        Me.lblSubject.Location = New System.Drawing.Point(891, 109)
        Me.lblSubject.Name = "lblSubject"
        Me.lblSubject.Size = New System.Drawing.Size(61, 20)
        Me.lblSubject.TabIndex = 7
        Me.lblSubject.Text = "Subject:"
        '
        'lblSeller
        '
        Me.lblSeller.AutoSize = True
        Me.lblSeller.Location = New System.Drawing.Point(903, 164)
        Me.lblSeller.Name = "lblSeller"
        Me.lblSeller.Size = New System.Drawing.Size(49, 20)
        Me.lblSeller.TabIndex = 8
        Me.lblSeller.Text = "Seller:"
        '
        'lblPurchase
        '
        Me.lblPurchase.AutoSize = True
        Me.lblPurchase.Location = New System.Drawing.Point(846, 219)
        Me.lblPurchase.Name = "lblPurchase"
        Me.lblPurchase.Size = New System.Drawing.Size(106, 20)
        Me.lblPurchase.TabIndex = 9
        Me.lblPurchase.Text = "Purchase Price:"
        '
        'lblPurchaser
        '
        Me.lblPurchaser.AutoSize = True
        Me.lblPurchaser.Location = New System.Drawing.Point(877, 275)
        Me.lblPurchaser.Name = "lblPurchaser"
        Me.lblPurchaser.Size = New System.Drawing.Size(75, 20)
        Me.lblPurchaser.TabIndex = 10
        Me.lblPurchaser.Text = "Purchaser:"
        '
        'lblSale
        '
        Me.lblSale.AutoSize = True
        Me.lblSale.Location = New System.Drawing.Point(876, 335)
        Me.lblSale.Name = "lblSale"
        Me.lblSale.Size = New System.Drawing.Size(76, 20)
        Me.lblSale.TabIndex = 11
        Me.lblSale.Text = "Sale Price:"
        '
        'lblRating
        '
        Me.lblRating.AutoSize = True
        Me.lblRating.Location = New System.Drawing.Point(900, 390)
        Me.lblRating.Name = "lblRating"
        Me.lblRating.Size = New System.Drawing.Size(52, 20)
        Me.lblRating.TabIndex = 12
        Me.lblRating.Text = "Rating"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(976, 60)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(176, 27)
        Me.txtName.TabIndex = 13
        '
        'txtRating
        '
        Me.txtRating.Location = New System.Drawing.Point(976, 387)
        Me.txtRating.Name = "txtRating"
        Me.txtRating.Size = New System.Drawing.Size(176, 27)
        Me.txtRating.TabIndex = 14
        '
        'txtSale
        '
        Me.txtSale.Location = New System.Drawing.Point(976, 332)
        Me.txtSale.Name = "txtSale"
        Me.txtSale.Size = New System.Drawing.Size(176, 27)
        Me.txtSale.TabIndex = 15
        '
        'txtPurchaser
        '
        Me.txtPurchaser.Location = New System.Drawing.Point(976, 272)
        Me.txtPurchaser.Name = "txtPurchaser"
        Me.txtPurchaser.Size = New System.Drawing.Size(176, 27)
        Me.txtPurchaser.TabIndex = 16
        '
        'txtPurchase
        '
        Me.txtPurchase.Location = New System.Drawing.Point(976, 216)
        Me.txtPurchase.Name = "txtPurchase"
        Me.txtPurchase.Size = New System.Drawing.Size(176, 27)
        Me.txtPurchase.TabIndex = 17
        '
        'txtSeller
        '
        Me.txtSeller.Location = New System.Drawing.Point(976, 161)
        Me.txtSeller.Name = "txtSeller"
        Me.txtSeller.Size = New System.Drawing.Size(176, 27)
        Me.txtSeller.TabIndex = 18
        '
        'txtSubject
        '
        Me.txtSubject.Location = New System.Drawing.Point(976, 106)
        Me.txtSubject.Name = "txtSubject"
        Me.txtSubject.Size = New System.Drawing.Size(176, 27)
        Me.txtSubject.TabIndex = 19
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(976, 439)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(176, 58)
        Me.btnAdd.TabIndex = 20
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnSort
        '
        Me.btnSort.Location = New System.Drawing.Point(775, 439)
        Me.btnSort.Name = "btnSort"
        Me.btnSort.Size = New System.Drawing.Size(167, 58)
        Me.btnSort.TabIndex = 21
        Me.btnSort.Text = "Sort Rating"
        Me.btnSort.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(42, 44)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(167, 58)
        Me.btnSearch.TabIndex = 22
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'frmBook
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LemonChiffon
        Me.ClientSize = New System.Drawing.Size(1233, 515)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.btnSort)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtSubject)
        Me.Controls.Add(Me.txtSeller)
        Me.Controls.Add(Me.txtPurchase)
        Me.Controls.Add(Me.txtPurchaser)
        Me.Controls.Add(Me.txtSale)
        Me.Controls.Add(Me.txtRating)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblRating)
        Me.Controls.Add(Me.lblSale)
        Me.Controls.Add(Me.lblPurchaser)
        Me.Controls.Add(Me.lblPurchase)
        Me.Controls.Add(Me.lblSeller)
        Me.Controls.Add(Me.lblSubject)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.lstBooks)
        Me.Name = "frmBook"
        Me.Text = "frmBook"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstBooks As ListBox
    Friend WithEvents btnHome As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblHeading As Label
    Friend WithEvents lblTitle As Label
    Friend WithEvents btnEdit As Button
    Friend WithEvents lblName As Label
    Friend WithEvents lblSubject As Label
    Friend WithEvents lblSeller As Label
    Friend WithEvents lblPurchase As Label
    Friend WithEvents lblPurchaser As Label
    Friend WithEvents lblSale As Label
    Friend WithEvents lblRating As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtRating As TextBox
    Friend WithEvents txtSale As TextBox
    Friend WithEvents txtPurchaser As TextBox
    Friend WithEvents txtPurchase As TextBox
    Friend WithEvents txtSeller As TextBox
    Friend WithEvents txtSubject As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnSort As Button
    Friend WithEvents btnSearch As Button
End Class
