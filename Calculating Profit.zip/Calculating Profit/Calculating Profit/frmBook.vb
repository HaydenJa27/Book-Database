﻿Imports System.Diagnostics.Eventing.Reader
Imports System.IO

Public Class frmBook
    Private Sub frmBook_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'declare the variables
        Dim totaldetails As StreamReader = File.OpenText("shopdata.txt")
        Dim strdetails As String

        'check the next line in the text file
        Do While totaldetails.Peek <> -1
            strdetails = totaldetails.ReadLine()

            'add the text file to the list box
            lstBooks.Items.Add(strdetails)

        Loop

        'close the list box
        totaldetails.Close()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        'close the list box form and open the homescreen
        Me.Close()
        frmMain.Show()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'end the program
        End
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        Dim strsplit(6) As String
        Dim totaldetails As StreamReader = File.OpenText("shopdata.txt")
        Dim strdetails As String

        If lstBooks.SelectedIndex <> -1 Then

            strdetails = lstBooks.Items(lstBooks.SelectedIndex)

            lstBooks.Items.Remove(lstBooks.Text)

            strsplit = strdetails.Split(",")

            txtName.Text = strsplit(0)
            txtSubject.Text = strsplit(1)
            txtSeller.Text = strsplit(2)
            txtPurchase.Text = strsplit(3)
            txtPurchaser.Text = strsplit(4)
            txtSale.Text = strsplit(5)
            txtRating.Text = strsplit(6)
        Else
            MsgBox("You need to select a record to edit")
        End If



    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim str As String

        str = txtName.Text + "," + txtSubject.Text + "," + txtSeller.Text + "," + txtPurchase.Text + "," + txtPurchaser.Text + "," + txtSale.Text + "," + txtRating.Text

        lstBooks.Items.Add(str)

        txtName.Text = ""
        txtSubject.Text = ""
        txtSeller.Text = ""


    End Sub

    Private Sub btnSort_Click(sender As Object, e As EventArgs) Handles btnSort.Click
        Dim list(6) As String
        Dim temp As String
        Dim n As Integer = 8
        Dim min As String
        Dim totaldetails As StreamReader = File.OpenText("shopdata.txt")
        Dim strdetails As String
        Dim temp2 As String



        Do While totaldetails.Peek <> -1
            strdetails = totaldetails.ReadLine()

            list = strdetails.Split(",")

            temp2 = list(6)
            list(6) = list(0)
            list(0) = temp2

            For j As Integer = 0 To n - 1
                min = j
                For i As Integer = j To n - 1

                    If list(i) < list(min) Then
                        min = i
                    End If
                Next
                If min <> j Then
                    temp = list(j)
                    list(j) = list(min)
                    list(min) = temp

                End If
            Next


        Loop


    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim totaldetails As StreamReader = File.OpenText("shopdata.txt")
        Dim strdetails As String

        MsgBox("")
        'check the next line in the text file
        Do While totaldetails.Peek <> -1
            strdetails = totaldetails.ReadLine()

        Loop
    End Sub
End Class