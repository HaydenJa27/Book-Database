﻿Imports System.IO

Public Class frmMain
    'declare variables
    Dim dblProfit As Double
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        'declare the text file and the variables
        Dim totaldetails As StreamReader = File.OpenText("shopdata.txt")
        Dim strSplit(6) As String
        Dim strDetails As String

        'enable the clear button
        btnClear.Enabled = True

        'see if there is another line to read
        Do While totaldetails.Peek <> -1

            'get the current record into a string
            strDetails = totaldetails.ReadLine()

            'split the string into individual strings
            strSplit = strDetails.Split(",")

            'if there is no sell price then make the purchase price a negative profit
            If strSplit(5) = "NA" Then
                dblProfit = dblProfit - strSplit(3)
            Else
                'if there is a sell price then take the purchase price off it and add it to the profit
                dblProfit = dblProfit + (strSplit(5) - strSplit(3))
            End If

        Loop

        'display the profit in 0.00 format
        lblProfit.Text = "$" & Format(dblProfit, "0.00")

        'disable the calculate button
        btnCalculate.Enabled = False

    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        'hide the main form and open the listbox form 
        Me.Hide()
        frmBook.Show()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'end the program
        End
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'reset the text and the profit back to 0
        lblProfit.Text = "$0.00"
        dblProfit = 0

        'enable the calculate button
        btnCalculate.Enabled = True

        'disable the clear button
        btnClear.Enabled = False
    End Sub
End Class
